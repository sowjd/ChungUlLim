<?php
            include_once "connectDB.php";
            //header('Content-Type: text/html; charset=utf-8');

            $bno = $_POST['idx'];
            $nickname = $_POST['nickname'];
            $title = $_POST['title'];
            $message = $_POST['message'];
            $stime = $_POST['stime'];
            echo "idx".$bno."<br />\n";
            echo $nickname."<br />\n";
            echo $title."<br />\n";
            echo $message."<br />\n";
            echo $stime."<br />\n";
            //$rlt = $connectDB->query("select * from Customer where idx='$bno';");
            //$event = mysqli_fetch_array($rlt);



            $query = "UPDATE Customer SET nickname='".$nickname."',title='".$title."',message='".$message."',stime='".$stime."' WHERE idx='".$bno."'";
            //echo $query;
            $rlt = $dbConnect->query($query);
            if(!$rlt)
            echo "DB저장 실패";

            $dbConnect -> close();

        echo "<script>alert('수정되었습니다.');</script>";
        ?>
<meta http-equiv="refresh" content="0 url=../process/ad_edit.php?idx=<?php echo $bno ?>" />