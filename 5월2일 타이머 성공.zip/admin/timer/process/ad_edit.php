<?php
    include "connectDB.php";
    $bno = $_GET['idx'];
    $rlt = $dbConnect->query("select * from Customer where idx='$bno';");
    $Customer = mysqli_fetch_array($rlt);
?>
<!DOCTYPE html>
<html lang ="ko">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Set character encoding -->
  <meta charset="utf-8">
  <title>A_Push</title>
  <link rel = "stylesheet" href="../../../bootstrap/css/bootstrap.css">
    <script type="text/javascript" charset="utf-8" >
        function sendPush(idx, title, message, stime) {
            var confirmPush = confirm('푸시 알림을 보내시겠습니까?');
            if (confirmPush) {
                    $.ajax({
                            type: 'POST',
                            url: 'https://ullimtime.com:3000/process/sendPush',
                            async: true,
                            contentType: 'application/json',
                            data: JSON.stringify({
                                "tag": 'timer',
                                "idx": idx,
                                "findClientSql": "SELECT subscription FROM Customer",
                                "title" : title,
                                "message" : message,
                                "stime" : stime
                            }),
                            dataType:'json',
                            processData: true,
                            success: function(data){
                                alert("푸쉬 알림을 전송했습니다.");
                            }
                     });
            }
            return;
        }
  </script>
</head>
<body>
    <style>
        body {
            margin: 0;
        }
        .image{
            position : relative;
            height: 726px;
            background: url(../../../images/darkcafeimage.jpg) no-repeat center center;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            height: calc(100vh);
            min-height: 200px;
        }
        .image.container{
        position:absolute;
        color:white;
        }
        .hello{
        color:white;
        font-size:3rem;
        text-align: center;
        }
        .push_edit{
        position : absolute;
        color : white;
        }
        .text-center{
            text-align: center;
        }
				tr{
					text-align: center;
				}
    </style>

    <div class="image"`>
        <br><br><br>
        <div class="container">
            <div class="starter-template">
                <h1 class = "hello">Edit Page</h1>
            </div>
        </div><!-- /.container -->

        <!--event table-->
        <div class ="container">
        <div class = "jumbotron">
        <div id="push_edit">
          <form action="ad_edit_ok.php" method="post" enctype="multipart/form-data">
          <input type="hidden" name="idx" value="<?=$bno?>">          
              <div class="form-group">
                  <label for="nickname">Nickname</label>
                  <textarea class="form-control" id="nickname" name="nickname" rows="1" id="inh"><?php echo $Customer['nickname']; ?></textarea>
              </div>
              <div class="form-group">
                  <label for="title">Title</label>
                  <textarea class="form-control" id="title" name="title" rows="1" id="inh"><?php echo $Customer['title']; ?></textarea>
              </div>
              <div class="form-group">
                  <label for="message">Message</label>
                  <textarea class="form-control" id="message" name="message" rows="3" id="inh"><?php echo $Customer['message']; ?></textarea>
              </div>
              <div class="form-group">
                  <label for="stime">WantTime</label>
                  <textarea class="form-control" type="datetime" id="stime" name="stime" rows="3" id="inh"><?php echo $Customer['stime']; ?></textarea>
              </div>
              <!-- placeholder="2018-03-07 22:00:00" -->
              <div class="bt_se">
                  <input type="submit" class="btn btn-default btn-sm" value="수정하기">
              </div>
                  <a href="#" onclick="sendPush('<?php echo $Customer['idx']; ?>','<?php echo $Customer['title']; ?>','<?php echo $Customer['message']; ?>','<?php echo $Customer['stime']; ?>' )">Push</a>
          </form>
        </div>
        </div>
        </div>
    </div>
<script src="../../../bootstrap/js/jquery-3.3.1.min.js"></script>
<script src="../../../bootstrap/js/bootstrap.js"></script>

    </body>
</html>
